/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javasocs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import javasocs.HexFormatUtils;
/**
 *
 * @author pedro
 */
public class JavaSocs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
            
        
        int port =  55502;
        try (ServerSocket serverSocket = new ServerSocket(port)) 
        {
            System.out.println("Server is listening on port " + port);
               String data; data="";
         
                Socket socket = serverSocket.accept();
                System.out.println("New client connected");
        
                                     System.out.println(((InetSocketAddress) socket.getRemoteSocketAddress() ) );

                InputStream input = socket.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                boolean go = true;
                String text;
                
                do 
                {
                    text =  reader.readLine();
                    System.out.println( HexFormatUtils.encodeHex(text.getBytes(Charset.forName("UTF-8")))  );
                  
                  
                } while (go==true);
                 System.out.println( data);
                socket.close();
 
        }
        catch (IOException ex) 
        {
            System.out.println("Server exception: " + ex.getMessage());
        }
    }

   
}
